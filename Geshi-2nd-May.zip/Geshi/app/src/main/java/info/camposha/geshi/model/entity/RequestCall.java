package info.camposha.geshi.model.entity;

import java.util.ArrayList;

import info.camposha.geshi.common.Constants;

public class RequestCall {
    private int status = Constants.STOPPED;
    private ArrayList<Song> songs=new ArrayList<>();

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public ArrayList<Song> getSongs() {
        return songs;
    }

    public void setSongs(ArrayList<Song> songs) {
        this.songs = songs;
    }
}
