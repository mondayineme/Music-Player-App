package info.camposha.geshi.view;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

import easyadapter.dc.com.library.EasyAdapter;
import info.camposha.geshi.R;
import info.camposha.geshi.model.entity.Song;
import info.camposha.geshi.common.Constants;
import info.camposha.geshi.databinding.ModelBinding;
import info.camposha.geshi.model.repository.SongsRepository;
import info.camposha.geshi.viewmodel.SongsViewModel;

import static info.camposha.geshi.common.CacheManager.SONGS_CACHE;
import static info.camposha.geshi.common.CacheManager.SONG_POSITION;
import static info.camposha.geshi.common.Constants.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE;

public class HomeActivity extends AppCompatActivity {

    RecyclerView songsRV;
    TextView currentPosTV, totalDurationTV;
    private boolean hasFinished = false;
    private Song currentSong;
    SeekBar progressSB;
    ImageButton playBtn, nextBtn, prevBtn;
    MediaPlayer mMediaPlayer;

    Handler mHandler = new Handler();
    EasyAdapter<Song, ModelBinding> adapter = null;

    private SongsViewModel sr;

    private void initializeViews() {
        totalDurationTV = findViewById(R.id.totalDurationTV);
        currentPosTV = findViewById(R.id.currentPosTV);
        progressSB = findViewById(R.id.progressSB);
        playBtn = findViewById(R.id.playBtn);
        nextBtn = findViewById(R.id.nextBtn);
        prevBtn = findViewById(R.id.prevBtn);

        songsRV = findViewById(R.id.songsRV);
        songsRV.setLayoutManager(new LinearLayoutManager(this));
    }


    private int getPosition(Song s) {
        int pos = 0;
        for (Song song : SONGS_CACHE) {
            if (s.getId().equalsIgnoreCase(song.getId())) {
                return SONGS_CACHE.indexOf(s);
            }
        }
        return pos;
    }

    private void handleEvents() {
        playBtn.setOnClickListener(view -> {
            if(currentSong != null){
                playOrPause(currentSong);
            }else {
                show("Please add some songs first");
            }
        });

        nextBtn.setOnClickListener(view -> {
            refreshRecyclerView(false);
            SONG_POSITION = getPosition(currentSong) + 1;
            if (SONG_POSITION >= SONGS_CACHE.size()) {
                SONG_POSITION = 0;
            }
            cleanUpMediaPlayer();
            Song nextSong = SONGS_CACHE.get(SONG_POSITION);
            playOrPause(nextSong);
        });

        prevBtn.setOnClickListener(view -> {
            refreshRecyclerView(false);
            SONG_POSITION--;
            if (SONG_POSITION < 0) {
                if(SONGS_CACHE.size() > 0){
                    SONG_POSITION = SONGS_CACHE.size()-1;
                }else{
                    SONG_POSITION=0;
                }
            }
            Song prevSong = SONGS_CACHE.get(SONG_POSITION);
            cleanUpMediaPlayer();
            playOrPause(prevSong);
        });
        progressSB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (b) {
                    if (getPlayer() == null) {
                        show("Please add some songs to Play");
                        return;
                    }
                    mMediaPlayer.seekTo(sr.getTimeFromProgress(seekBar.getProgress(), getPlayer().getDuration()));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void cleanUpMediaPlayer() {
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
    }

    private void refreshRecyclerView(boolean playing) {
        currentSong.setPlaying(playing);
        SONGS_CACHE.set(getPosition(currentSong), currentSong);
        adapter.notifyDataSetChanged();
    }

    private void checkPermissionsThenLoadSongs() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            // No explanation needed, we can request the permission.
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
            show("Hey Please grant this app the permission to read external storage first");
        } else {
            fetchAllSongs();
        }
    }

    private void show(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void setupRecycler(ArrayList<Song> songs) {

        adapter = new EasyAdapter<Song, ModelBinding>(R.layout.model) {
            @Override
            public void onBind(@NonNull ModelBinding mb, @NonNull Song song) {
                mb.titleTV.setText(song.getTitle());
                if (song.isPlaying() && !hasFinished) {
                    mb.playBtn.setImageResource(android.R.drawable.ic_media_pause);
                    mb.titleTV.setTextColor(Color.BLUE);
                    mb.titleTV.setTypeface(null, Typeface.BOLD);
                } else {
                    mb.playBtn.setImageResource(android.R.drawable.ic_media_play);
                    mb.titleTV.setTextColor(Color.BLACK);
                    mb.titleTV.setTypeface(null, Typeface.NORMAL);

                    if (hasFinished) {
                        mb.playBtn.setImageResource(android.R.drawable.ic_media_play);
                        mb.titleTV.setTextColor(Color.BLACK);
                        mb.titleTV.setTypeface(null, Typeface.NORMAL);
                    } else {
                        if (currentSong != null && currentSong.getId() == song.getId()) {
                            mb.playBtn.setImageResource(android.R.drawable.ic_media_play);
                            mb.titleTV.setTextColor(Color.BLUE);
                            mb.titleTV.setTypeface(null, Typeface.BOLD);
                        }
                    }
                }

                mb.playBtn.setOnClickListener(view -> {
                    if (!song.isPlaying()) {
                        if (SONG_POSITION != getPosition(song)) {
                            if (mMediaPlayer != null) {
                                mMediaPlayer.release();
                                mMediaPlayer = null;
                            }
                        }
                        SONG_POSITION = getPosition(song);
                        currentSong = SONGS_CACHE.get(SONG_POSITION);

                        playOrPause(song);
                        show("Now Playing: " + song.getTitle());
                        mb.playBtn.setImageResource(android.R.drawable.ic_media_pause);
                        mb.titleTV.setTextColor(Color.BLUE);
                        mb.titleTV.setTypeface(null, Typeface.BOLD);
                    } else {
                        if (SONG_POSITION != getPosition(song)) {
                            if (mMediaPlayer != null) {
                                mMediaPlayer.release();
                                mMediaPlayer = null;
                            }
                        }
                        SONG_POSITION = getPosition(song);

                        show("Stopped: " + song.getTitle());
                        playOrPause(song);
                        mb.playBtn.setImageResource(android.R.drawable.ic_media_play);
                        mb.titleTV.setTextColor(Color.BLUE);
                        mb.titleTV.setTypeface(null, Typeface.BOLD);
                    }
                });
            }
        };
        songsRV.setLayoutManager(new LinearLayoutManager(this));
        adapter.addAll(songs, true);
        songsRV.setAdapter(adapter);
    }

    private void fetchAllSongs() {
        sr.loadAllSongs(this).observe(this, requestCall -> {
            LinkedHashSet<Song> linkedHashSet=new LinkedHashSet<>(requestCall.getSongs());
            SONGS_CACHE.clear();
            SONGS_CACHE.addAll(linkedHashSet);
            if(currentSong == null && SONGS_CACHE.size() > 0){
                currentSong=SONGS_CACHE.get(0);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    fetchAllSongs();
                    // permission was granted, yay! Do the
                    // SONGS_CACHE-related task you need to do.

                } else {
                    show("Please grant us permission to read external storage so that we load songs");
                }
                return;

        }
    }

    private MediaPlayer getPlayer() {
        if (mMediaPlayer == null) {
            if (currentSong == null) {
                if (SONGS_CACHE.size() > 0) {
                    currentSong = SONGS_CACHE.get(0);
                } else {
                    return null;
                }
            }
            mMediaPlayer = MediaPlayer.create(this, Uri.parse(currentSong.getData()));
        }
        return mMediaPlayer;
    }


    private void playOrPause(Song song) {
        currentSong = song;
        if (getPlayer() == null) {
            show("You don't have any song to play.Please add some songs first");
            return;
        }
        hasFinished = false;
        if (getPlayer().isPlaying()) {
            sr.pause(getPlayer(), this, song).observe(this, requestCall -> {
                if (requestCall.getStatus() == Constants.STOPPED) {
                    song.setPlaying(false);
                    refreshRecyclerView(song.isPlaying());
                    playBtn.setImageResource(android.R.drawable.ic_media_play);
                }
            });

        } else {
            sr.play(getPlayer(), this, song).observe(this, requestCall -> {
                if (requestCall.getStatus() == Constants.PLAYING) {
                    song.setPlaying(true);
                    SONG_POSITION = getPosition(song);
                    refreshRecyclerView(song.isPlaying());
                    playBtn.setImageResource(android.R.drawable.ic_media_pause);
                    updateSongProgress();

                }
            });

        }
    }

    private void updateSongProgress() {
        mHandler.postDelayed(runnable, 1000);
    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {

            if (!hasFinished) {
                int currentDuration = mMediaPlayer.getCurrentPosition();
                int totalDuration = mMediaPlayer.getDuration();

                currentPosTV.setText(sr.convertToTimerMode(String.valueOf(currentDuration)));
                progressSB.setProgress(sr.getSongProgress(totalDuration, currentDuration));
                totalDurationTV.setText(sr.convertToTimerMode(String.valueOf(totalDuration)));

                if (progressSB.getProgress() >= 99 && !mMediaPlayer.isPlaying()) {
                    playBtn.setImageResource(android.R.drawable.ic_media_play);
                    hasFinished = true;
                    adapter.notifyDataSetChanged();
//                    show("Finished");
                    //Click Next to play next song
                    nextBtn.performClick();
                } else {
                    hasFinished = false;
                }
                mHandler.postDelayed(this, 1000);

            }

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        sr= ViewModelProviders.of(this).get(SongsViewModel.class);
        initializeViews();
        handleEvents();
    }

    @Override
    protected void onResume() {
        super.onResume();

        checkPermissionsThenLoadSongs();
        setupRecycler(SONGS_CACHE);

    }

}
