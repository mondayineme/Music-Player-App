package info.camposha.geshi.common;

/**
 * ANDROID: http://www.camposha.info : Oclemy.
 */
public class Constants {
    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1;

    public static final int STOPPED = -1;
    public static final int LOADING = 0;
    public static final int PLAYING = 1;
}
