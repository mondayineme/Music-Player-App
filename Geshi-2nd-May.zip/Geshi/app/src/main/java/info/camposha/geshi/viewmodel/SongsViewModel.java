package info.camposha.geshi.viewmodel;

import android.app.Application;
import android.content.Context;
import android.media.MediaPlayer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import info.camposha.geshi.model.entity.RequestCall;
import info.camposha.geshi.model.entity.Song;
import info.camposha.geshi.model.repository.SongsRepository;

public class SongsViewModel extends AndroidViewModel {
    private SongsRepository sr=new SongsRepository();
    public SongsViewModel(@NonNull Application application) {
        super(application);
    }
    public MutableLiveData<RequestCall> loadAllSongs(AppCompatActivity a){
        return sr.fetchAllSongs(a);
    }
    public MutableLiveData<RequestCall> play(MediaPlayer mMediaPlayer, Context c, Song s){
        return sr.play(mMediaPlayer,c,s);
    }
    public MutableLiveData<RequestCall> pause(MediaPlayer mMediaPlayer, Context c, Song s){
        return sr.pause(mMediaPlayer,c,s);
    }
    public int getTimeFromProgress(int progress, int duration){
        return sr.getTimeFromProgress(progress,duration);
    }
    public int getSongProgress(int totalDuration, int currentDuration){
        return sr.getSongProgress(totalDuration,currentDuration);
    }
    public String convertToTimerMode(String songDuration){
        return sr.convertToTimerMode(songDuration);
    }
}
