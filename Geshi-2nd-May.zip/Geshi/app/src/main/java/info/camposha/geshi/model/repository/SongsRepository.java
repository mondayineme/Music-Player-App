package info.camposha.geshi.model.repository;

import android.content.Context;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.MediaStore;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;

import info.camposha.geshi.common.Constants;
import info.camposha.geshi.model.entity.RequestCall;
import info.camposha.geshi.model.entity.Song;

import static info.camposha.geshi.common.Constants.PLAYING;
import static info.camposha.geshi.common.Constants.STOPPED;

public class SongsRepository {

    /**
     * Cursor is an interface that provides random read-write access to the result set
     * returned by a database query.
     *
     * @param cursor
     * @return
     */
    private Song convertToSong(Cursor cursor) {
        Song song = new Song();
        song.setId(cursor.getString(0));
        song.setArtist(cursor.getString(1));
        song.setTitle(cursor.getString(2));
        song.setData(cursor.getString(3));
        song.setDisplayName(cursor.getString(4));
        song.setDuration(cursor.getString(5));
        song.setPlaying(false);
        return song;
    }

    /**
     * Fetch all songs from the device
     * @param c
     * @return
     */
    public MutableLiveData<RequestCall> fetchAllSongs(AppCompatActivity c) {
        RequestCall r = new RequestCall();
        r.setStatus(Constants.LOADING);
        MutableLiveData<RequestCall> mLiveData = new MutableLiveData<>();
        ArrayList<Song> songs = new ArrayList<>();
        r.setSongs(songs);
        mLiveData.setValue(r);

        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String[] projection = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DURATION
        };

        Cursor cursor = c.managedQuery(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                null);


        while (cursor.moveToNext()) {
            songs.add(convertToSong(cursor));
        }
        r.setStatus(STOPPED);
        r.setSongs(songs);
        mLiveData.postValue(r);
        return mLiveData;
    }

    /**
     * Play A Song
     * @param mMediaPlayer
     * @param c
     * @param song
     * @return
     */
    public MutableLiveData<RequestCall> play(MediaPlayer mMediaPlayer, Context c, Song song) {
        RequestCall r = new RequestCall();
        r.setStatus(STOPPED);
        r.setSongs(new ArrayList<>());
        MutableLiveData<RequestCall> mLiveData = new MutableLiveData<>();
        mLiveData.setValue(r);

        if (mMediaPlayer == null) {
            mMediaPlayer = MediaPlayer.create(c, Uri.parse(song.getData()));
        }
        mMediaPlayer.start();

        r.setStatus(PLAYING);
        mLiveData.postValue(r);
        return mLiveData;
    }

    /**
     * Pause a MediaPlayer
     * @param mMediaPlayer
     * @param c
     * @param song
     * @return
     */
    public MutableLiveData<RequestCall> pause(MediaPlayer mMediaPlayer, Context c, Song song) {
        RequestCall r = new RequestCall();
        r.setSongs(new ArrayList<>());
        MutableLiveData<RequestCall> mLiveData = new MutableLiveData<>();
        mLiveData.setValue(r);

        if (mMediaPlayer == null) {
            mMediaPlayer = MediaPlayer.create(c, Uri.parse(song.getData()));
        } else {
            mMediaPlayer.pause();
            r.setStatus(STOPPED);
            mLiveData.postValue(r);
        }
        return mLiveData;
    }

    /**
     * Obtain time based on progress and duration
     * @param progress
     * @param duration
     * @return
     */
    public int getTimeFromProgress(int progress, int duration) {
        return (duration * progress) / 100;
    }

    /**
     * Get song progress
     * @param totalDuration
     * @param currentDuration
     * @return
     */
    public int getSongProgress(int totalDuration, int currentDuration) {
        return (currentDuration * 100) / totalDuration;
    }

    /**
     * Convert To Timer Mode
     * @param songDuration
     * @return
     */
    public String convertToTimerMode(String songDuration) {
        int duration = Integer.parseInt(songDuration);
        int hour = duration / (1000 * 60 * 60);
        int minute = (duration % (1000 * 60 * 60)) / (1000 * 60);
        int seconds = ((duration % (1000 * 60 * 60)) % (1000 * 60)) / (1000);
        String finalString = "";
        if (hour < 10)
            finalString += "0";
        finalString += hour + ":";
        if (minute < 10)
            finalString += "0";
        finalString += minute + ":";
        if (seconds < 10)
            finalString += "0";
        finalString += seconds;

        return finalString;
    }

}
