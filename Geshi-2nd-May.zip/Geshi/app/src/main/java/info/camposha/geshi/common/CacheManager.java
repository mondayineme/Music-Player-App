package info.camposha.geshi.common;

import java.util.ArrayList;

import info.camposha.geshi.model.entity.Song;

public class CacheManager {
    public static int SONG_POSITION = 0;
    public static ArrayList<Song> SONGS_CACHE = new ArrayList<>();
}
